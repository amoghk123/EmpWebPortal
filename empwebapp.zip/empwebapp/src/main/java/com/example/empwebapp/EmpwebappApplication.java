package com.example.empwebapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpwebappApplication {
    public static void main(String[] args) {
        SpringApplication.run(EmpwebappApplication.class, args);
    }
}
