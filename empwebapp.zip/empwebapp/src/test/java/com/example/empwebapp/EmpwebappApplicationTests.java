package com.example.empwebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpwebappApplicationTests {

	@Test
	void contextLoads() {
	}

}
